"""Static portfolio validator and HTML generator for Bhoge Tejaswi."""

from __future__ import annotations

import html
import json
from pathlib import Path
from typing import Any

ROOT_DIR = Path(__file__).resolve().parent
DATA_FILE = ROOT_DIR / "portfolio_data.json"
INDEX_FILE = ROOT_DIR / "index.html"


def load_portfolio_data(path: Path = DATA_FILE) -> dict[str, Any]:
    """Load structured portfolio metadata from JSON."""
    if not path.exists():
        raise FileNotFoundError(f"Portfolio data file not found: {path}")
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def validate_certificates(certificates: list[dict[str, str]]) -> list[str]:
    """Verify every referenced certificate PDF exists in the repository root."""
    missing: list[str] = []
    for cert in certificates:
        pdf_name = cert.get("file", "")
        if pdf_name and not (ROOT_DIR / pdf_name).exists():
            missing.append(pdf_name)
    return missing


def render_skill_cards(skills: list[dict[str, Any]]) -> str:
    """Render HTML article blocks for each skill category."""
    blocks: list[str] = []
    for category in skills:
        tags = "".join(f"<span>{html.escape(item)}</span>" for item in category["items"])
        blocks.append(
            "<article>"
            f"<b>{html.escape(category['symbol'])}</b>"
            f"<h3>{html.escape(category['title'])}</h3>"
            f"<p>{html.escape(category['description'])}</p>"
            f'<div class="tags">{tags}</div>'
            "</article>"
        )
    return "".join(blocks)


def render_certificate_cards(certificates: list[dict[str, str]]) -> str:
    """Render Wolfram U and academic certificate blocks."""
    cards: list[str] = []
    for cert in certificates:
        cards.append(
            "<article>"
            '<div class="seal">W<span>U</span></div>'
            "<div>"
            f"<small>{html.escape(cert['issuer'])}</small>"
            f"<h3>{html.escape(cert['title'])}</h3>"
            f"<p>{html.escape(cert['details'])}</p>"
            f'<a href="{html.escape(cert["file"])}" target="_blank" rel="noopener">'
            "View certificate ↗</a>"
            "</div>"
            "</article>"
        )
    return "".join(cards)


def build_summary_report(data: dict[str, Any]) -> str:
    """Generate a terminal-friendly summary of the portfolio configuration."""
    missing = validate_certificates(data.get("certificates", []))
    lines = [
        f"Portfolio Owner : {data['owner']['name']}",
        f"Location        : {data['owner']['location']}",
        f"Contact Email   : {data['owner']['email']}",
        f"Skills Sections : {len(data.get('skills', []))}",
        f"Projects Listed : {len(data.get('projects', []))}",
        f"Certificates    : {len(data.get('certificates', []))}",
        f"Missing PDFs    : {', '.join(missing) if missing else 'None'}",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    portfolio = load_portfolio_data()
    print(build_summary_report(portfolio))
    if INDEX_FILE.exists():
        print(f"Verified live GitHub Pages entry file: {INDEX_FILE.name} ({INDEX_FILE.stat().st_size} bytes)")
